<!--Membuat sambungan ke db-->
<?php
$sambungan=mysqli_connect("localhost","root","","vaksin");
//sila lengkapkan kod aturcara

?>

